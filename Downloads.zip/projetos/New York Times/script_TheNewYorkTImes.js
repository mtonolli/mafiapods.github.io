function mostrarLista() {
    document.getElementById('listaSuspensa').style.display = 'block';
}

function ocultarLista() {
    document.getElementById('listaSuspensa').style.display = 'none';
}
