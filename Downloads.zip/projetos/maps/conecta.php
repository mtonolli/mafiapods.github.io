<?php

date_default_timezone_set('America/Sao_Paulo');

$pdo = new PDO("mysql:dbname=mapa;host=localhost;charset=utf8","root","");


?>